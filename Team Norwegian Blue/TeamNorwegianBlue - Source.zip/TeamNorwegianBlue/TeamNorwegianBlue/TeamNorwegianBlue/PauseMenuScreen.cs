﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace TeamNorwegianBlue
{
    public class PauseMenuScreen : Screen
    {
        public SpriteFont titlePauseMenuFont;
        public SpriteFont boldPauseMenuFont;
        public Texture2D pauseBackgroundShade;

        int currentSelection;
        int selectionChangeCooldown;
        int selectionCooldown;
        
        public override void initialize(GameMain gameMain)
        {
            currentSelection = 0;
        }

        public override void loadContent(GameMain gameMain)
        {
            titlePauseMenuFont = gameMain.Content.Load<SpriteFont>(@"TitleMainMenuFont");
            boldPauseMenuFont = gameMain.Content.Load<SpriteFont>(@"BoldMainMenuFont");
            pauseBackgroundShade = gameMain.Content.Load<Texture2D>(@"PauseBackgroundShade");
        }

        public override void update(GameMain gameMain)
        {
            if (selectionChangeCooldown == 0 && GamePad.GetState(PlayerIndex.One).ThumbSticks.Left.Y < -0.1f && currentSelection < 1) { currentSelection++; selectionChangeCooldown = 15;}
            if (selectionChangeCooldown == 0 && GamePad.GetState(PlayerIndex.One).ThumbSticks.Left.Y > 0.1f && currentSelection > 0) { currentSelection--; selectionChangeCooldown = 15; }
            if (selectionChangeCooldown > 0) selectionChangeCooldown--;

            if (selectionCooldown == 0 && GamePad.GetState(PlayerIndex.One).Buttons.A == ButtonState.Pressed)
            {
                switch (currentSelection)
                {
                    case 0:
                        gameMain.currentScreen = GameMain.gameScreen;
                        break;
                    case 1:
                        gameMain.currentScreen = GameMain.mainMenuScreen;
                        GameMain.gameScreen.reset(gameMain);
                        break;
                }
                selectionCooldown = 15;
            }
            if (selectionCooldown > 0) selectionCooldown--;
        }

        public override void draw(GameMain gameMain)
        {
            SpriteBatch spriteBatch = gameMain.spriteBatch;

            GameMain.gameScreen.draw(gameMain);
            
            spriteBatch.Draw(pauseBackgroundShade, new Rectangle(0, 0, 800, 600), Color.FromNonPremultiplied(128, 128, 128, 192));

            spriteBatch.DrawString(boldPauseMenuFont, "PAUSED", new Vector2(400 - boldPauseMenuFont.MeasureString("PAUSED").X / 2, 50), Color.Blue);

            switch(currentSelection)
            {
                case 0:
                    spriteBatch.DrawString(boldPauseMenuFont, "CONTINUE", new Vector2(400 - boldPauseMenuFont.MeasureString("CONTINUE").X / 2, 200), Color.Yellow);
                    spriteBatch.DrawString(boldPauseMenuFont, "EXIT TO MENU", new Vector2(400 - boldPauseMenuFont.MeasureString("EXIT TO MENU").X / 2, 400), Color.Black);
                    break;
                case 1:
                    spriteBatch.DrawString(boldPauseMenuFont, "CONTINUE", new Vector2(400 - boldPauseMenuFont.MeasureString("CONTINUE").X / 2, 200), Color.Black);
                    spriteBatch.DrawString(boldPauseMenuFont, "EXIT TO MENU", new Vector2(400 - boldPauseMenuFont.MeasureString("EXIT TO MENU").X / 2, 400), Color.Yellow);
                    break;
            }
        }
    }
}
