﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace TeamNorwegianBlue
{
    class PlayerRanged : Player
    {
        public int range;

        public PlayerRanged(Vector2 pos)
            : base(pos)
        {
            range = 256;
        }

        protected override void attack()
        {
            if (stamina < 10) return;
            stamina -= 10;
            Mob[] hit = Utils.rayTrace(this, range);
            for (int i = 0; i < 3; i++)
            {
                if (hit[i] == null) break;
                hit[i].attacked(40);
            }
        }
    }
}
