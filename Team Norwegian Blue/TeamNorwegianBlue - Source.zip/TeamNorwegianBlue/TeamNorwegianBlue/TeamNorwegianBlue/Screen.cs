﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace TeamNorwegianBlue
{
    public abstract class Screen
    {
        public abstract void initialize(GameMain gameMain);

        public abstract void loadContent(GameMain gameMain);

        public abstract void update(GameMain gameMain);

        public abstract void draw(GameMain gameMain);
    }
}
