﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TeamNorwegianBlue
{
    public class Heartometer
    {
        public static void Draw(SpriteBatch spriteBatch, Texture2D tex, Vector2 position, Color colour, float value)
        {
            spriteBatch.Draw(tex, new Rectangle((int)position.X, (int)position.Y, (int) (80 * value), 16), new Rectangle(0, 0, 40, 8), Color.White);
        }
    }
}
