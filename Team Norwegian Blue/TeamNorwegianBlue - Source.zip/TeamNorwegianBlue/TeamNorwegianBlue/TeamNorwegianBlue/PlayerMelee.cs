﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace TeamNorwegianBlue
{
    public class PlayerMelee : Player
    {
        public int range;

        public PlayerMelee(Vector2 pos)
            :base(pos)
        {
            range = 64;
        }

        protected override void attack()
        {
            if (stamina < 10) return;
            stamina -= 10;
            Mob[] hit = Utils.rayTrace(this, range);
            if (hit != null && hit.Length > 0) hit[0].attacked(40);
        }
    }
}
