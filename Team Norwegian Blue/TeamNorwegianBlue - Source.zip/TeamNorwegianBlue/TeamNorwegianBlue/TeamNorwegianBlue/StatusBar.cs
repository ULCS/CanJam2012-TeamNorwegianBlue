﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TeamNorwegianBlue
{
    public class StatusBar
    {
        public static void Draw(SpriteBatch spriteBatch, Texture2D tex, Vector2 position, Color colour, float value)
        {
            spriteBatch.Draw(tex, new Rectangle((int)position.X - 2, (int)position.Y - 2, 96 + 4, 8 + 4), new Rectangle(0, 0, 100, 12), Color.White);
            spriteBatch.Draw(tex, new Rectangle((int) position.X, (int) position.Y, (int) (96 * value), 8), new Rectangle(2, 2, 96, 8), colour);
        }
    }
}
