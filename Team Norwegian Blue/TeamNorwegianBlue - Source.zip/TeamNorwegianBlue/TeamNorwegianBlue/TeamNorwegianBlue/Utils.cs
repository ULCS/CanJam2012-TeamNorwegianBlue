﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

namespace TeamNorwegianBlue
{
    class Utils
    {
        public static Player getNearestPlayer(Vector2 position)
        {
            double distance = 1000000;
            Player nearest = null;
            foreach (Player P in GameMain.gameScreen.players)
            {
                if (P.isActive && P.isAlive && (nearest == null || getDistance(position, P.position) < distance))
                {
                    distance = getDistance(position, P.position);
                    nearest = P;
                }
            }
            return nearest;
        }

        public static Player getFurthestPlayer(Vector2 position)
        {
            double distance = 0;
            Player furthest = null;
            foreach (Player P in GameMain.gameScreen.players)
            {
                if (P.isActive && P.isAlive && (furthest == null || getDistance(position, P.position) > distance))
                {
                    distance = getDistance(position, P.position);
                    furthest = P;
                }
            }
            return furthest;
        }

        public static Player getStrongestPlayer()
        {
            float strongestHealth = 0;
            Player strongest = null;
            foreach (Player P in GameMain.gameScreen.players)
            {
                if (P.isActive && P.isAlive && (strongest == null || P.health > strongestHealth))
                {
                    strongestHealth = P.health;
                    strongest = P;
                }
            }
            return strongest;
        }

        public static Vector2 getAveragePlayerPos()
        {
            Vector2 total = Vector2.Zero;
            int alivePlayers = 0;
            foreach (Player P in GameMain.gameScreen.players)
            {
                if (P.isActive && P.isAlive)
                {
                    total += P.position;
                    alivePlayers++;
                }
            }
            if (alivePlayers > 0) return total / alivePlayers;
            else return Vector2.Zero;
        }

        public static double getMaxPlayerDistance()
        {
            double distance = 0;
            foreach (Player P in GameMain.gameScreen.players)
            {
                double dist = getDistance(P.position, getFurthestPlayer(P.position).position);
                if (P.isAlive && getDistance(P.position, getFurthestPlayer(P.position).position) > distance)
                    distance = getDistance(P.position, getFurthestPlayer(P.position).position);
            }
            return distance;
        }

        public static double getDistance(Vector2 position1, Vector2 position2)
        {
            return (position2 - position1).Length();
        }

        public static double getAngle(Vector2 position1, Vector2 position2)
        {
            return (float)Math.Atan2(position2.X - position1.X, -(position2.Y - position1.Y));
        }

        public static Mob getAtPosition(Vector2 position)
        {
            Texture2D playerTex = GameMain.gameScreen.player1Texes[0];
            foreach (Player P in GameMain.gameScreen.players)
            {
                if (P.position.X > position.X - playerTex.Width / 2 &&
                   P.position.X < position.X + playerTex.Width / 2 &&
                   P.position.Y > position.Y - playerTex.Height / 2 &&
                   P.position.Y < position.Y + playerTex.Height / 2)
                    return P;
            }
            Texture2D sheepTex = GameMain.gameScreen.sheepTexes[0];
            foreach (Sheep S in GameMain.gameScreen.sheep)
            {
                if (S.position.X > position.X - sheepTex.Width / 2 &&
                   S.position.X < position.X + sheepTex.Width / 2 &&
                   S.position.Y > position.Y - sheepTex.Height / 2 &&
                   S.position.Y < position.Y + sheepTex.Height / 2)
                    return S;
            }
            return null;
        }

        public static Mob getAtPositionExcluding(Vector2 position, Mob[] excludes)
        {
            Texture2D playerTex = GameMain.gameScreen.player1Texes[0];
            foreach (Player P in GameMain.gameScreen.players)
            {
                if (!excludes.Contains<Mob>(P) &&
                   P.position.X > position.X - playerTex.Width / 2 &&
                   P.position.X < position.X + playerTex.Width / 2 &&
                   P.position.Y > position.Y - playerTex.Height / 2 &&
                   P.position.Y < position.Y + playerTex.Height / 2)
                    return P;
            }
            Texture2D sheepTex = GameMain.gameScreen.sheepTexes[0];
            foreach (Sheep S in GameMain.gameScreen.sheep)
            {
                if (!excludes.Contains<Mob>(S) &&
                   S.position.X > position.X - sheepTex.Width / 2 &&
                   S.position.X < position.X + sheepTex.Width / 2 &&
                   S.position.Y > position.Y - sheepTex.Height / 2 &&
                   S.position.Y < position.Y + sheepTex.Height / 2)
                    return S;
            }
            return null;
        }

        public static Mob[] rayTrace(Mob origin, int range)
        {
            LinkedList<Mob> returnList = new LinkedList<Mob>();
            Vector2 increment = Vector2.Transform(new Vector2(0, 2), Matrix.CreateRotationZ((float) -origin.rotation));
            Vector2 position = origin.position;

            for (int i = 0; i < range; i += 2)
            {
                Mob mobAtPos = getAtPositionExcluding(position, new Mob[] { origin });
                if(mobAtPos != null && !returnList.Contains(mobAtPos)) returnList.AddLast(mobAtPos);
                position += increment;
            }
            return returnList.ToArray<Mob>();
        }

        public static Mob[] rayTrace(Vector2 origin, double angle, int range)
        {
            LinkedList<Mob> returnList = new LinkedList<Mob>();
            Vector2 increment = Vector2.Transform(new Vector2(0, 2), Matrix.CreateRotationZ((float) -angle));
            Vector2 position = origin;

            for (int i = 0; i < range; i += 2)
            {
                Mob mobAtPos = getAtPosition(position);
                if (mobAtPos != null && !returnList.Contains(mobAtPos)) returnList.AddLast(mobAtPos);
                position += increment;
            }
            return returnList.ToArray<Mob>();
        }
    }
}
