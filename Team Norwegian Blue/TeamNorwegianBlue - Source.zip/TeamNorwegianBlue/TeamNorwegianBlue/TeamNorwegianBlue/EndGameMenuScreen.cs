﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace TeamNorwegianBlue
{
    public class EndGameMenuScreen : Screen
    {
        public SpriteFont titleEndGameMenuFont;
        public SpriteFont boldEndGameMenuFont;
        public Texture2D endGameBackgroundShade;

        public override void initialize(GameMain gameMain)
        {
        }

        public override void loadContent(GameMain gameMain)
        {
            titleEndGameMenuFont = gameMain.Content.Load<SpriteFont>(@"TitleMainMenuFont");
            boldEndGameMenuFont = gameMain.Content.Load<SpriteFont>(@"BoldMainMenuFont");
            endGameBackgroundShade = gameMain.Content.Load<Texture2D>(@"PauseBackgroundShade");
        }

        public override void update(GameMain gameMain)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.A == ButtonState.Pressed)
            {
                gameMain.currentScreen = GameMain.mainMenuScreen;
                GameMain.gameScreen.reset(gameMain);
            }
        }

        public override void draw(GameMain gameMain)
        {
            SpriteBatch spriteBatch = gameMain.spriteBatch;

            GameMain.gameScreen.draw(gameMain);

            spriteBatch.Draw(endGameBackgroundShade, new Rectangle(0, 0, 800, 600), Color.FromNonPremultiplied(255, 128, 128, 192));

            spriteBatch.DrawString(boldEndGameMenuFont, "GAME OVER", new Vector2(400 - boldEndGameMenuFont.MeasureString("GAME OVER").X / 2, 50), Color.Gold);

            spriteBatch.DrawString(boldEndGameMenuFont, "Base Score: " + GameMain.gameScreen.score, new Vector2(400 - boldEndGameMenuFont.MeasureString("Base Score: " + GameMain.gameScreen.score).X / 2, 200), Color.Gold);

            spriteBatch.DrawString(boldEndGameMenuFont, "Time Bonus: " + (GameMain.gameScreen.time / 30), new Vector2(400 - boldEndGameMenuFont.MeasureString("Time Bonus: " + (GameMain.gameScreen.time / 30)).X / 2, 250), Color.Gold);

            spriteBatch.DrawString(boldEndGameMenuFont, "Final Score: " + (GameMain.gameScreen.score + (GameMain.gameScreen.time / 30)), new Vector2(400 - boldEndGameMenuFont.MeasureString("Final Score: " + (GameMain.gameScreen.score + (GameMain.gameScreen.time / 30))).X / 2, 300), Color.Gold);

            spriteBatch.DrawString(boldEndGameMenuFont, "Press A to return to the menu", new Vector2(400 - boldEndGameMenuFont.MeasureString("Press A to return to the menu").X / 2, 400), Color.Gold);
        }
    }
}
