﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace TeamNorwegianBlue
{
    public class GameScreen : Screen
    {
        public TNBCamera camera;
        public Player[] players = new Player[4];
        public LinkedList<Sheep> sheep = new LinkedList<Sheep>();
        public LinkedList<SheepGhost> sheepGhosts = new LinkedList<SheepGhost>();

        public SpriteFont standardGameFont;
        public SpriteFont boldGameFont;

        //0: Standing Forward
        //1: Moving Forward A
        //2: Moving Forward B
        //3: Moving Backward A (also Standing Backward)
        //4: Moving Backward B
        //5: Moving Right A (also Standing Right)
        //6: Moving Right B
        //7: Moving Left A (also Standing Left)
        //8: Moving Left B
        //9: Attacking Down
        //10: Attacking Up
        //11: Attacking Right
        //12: Attacking Left

        public Texture2D[] player1Texes = new Texture2D[13];
        public Texture2D[] player2Texes = new Texture2D[13];
        public Texture2D[] player3Texes = new Texture2D[13];
        public Texture2D[] player4Texes = new Texture2D[13];
        public Texture2D[][] allPlayerTexes;
        public Texture2D[] sheepTexes = new Texture2D[5];

        public Texture2D barTex;
        public Texture2D heartometerTex;
        public Texture2D groundTex;

        bool[] exitButtonPressed = new bool[4];
        public int sheepLimit;
        public long score;
        public long time;
        
        public override void initialize(GameMain gameMain)
        {
            camera = new TNBCamera(Vector2.Zero);

            players[0] = new PlayerMelee(new Vector2(0, 0));
            players[1] = new PlayerMelee(new Vector2(0, 0));
            players[2] = new PlayerMelee(new Vector2(0, 0));
            players[3] = new PlayerMelee(new Vector2(0, 0));

            allPlayerTexes = new Texture2D[][] {player1Texes, player2Texes, player3Texes, player4Texes};

            exitButtonPressed[0] = false;
            exitButtonPressed[1] = false;
            exitButtonPressed[2] = false;
            exitButtonPressed[3] = false;

            if (GamePad.GetState(PlayerIndex.One).IsConnected) players[0].isActive = true;
            if (GamePad.GetState(PlayerIndex.Two).IsConnected) players[1].isActive = true;
            if (GamePad.GetState(PlayerIndex.Three).IsConnected) players[2].isActive = true;
            if (GamePad.GetState(PlayerIndex.Four).IsConnected) players[3].isActive = true;

            sheepLimit = 64;
            score = 0;
            time = 0;
        }

        public override void loadContent(GameMain gameMain)
        {
            standardGameFont = gameMain.Content.Load<SpriteFont>(@"StandardGameFont");
            boldGameFont = gameMain.Content.Load<SpriteFont>(@"BoldGameFont");

            //0: Standing Forward
            //1: Moving Forward A
            //2: Moving Forward B
            //3: Moving Backward A (also Standing Backward)
            //4: Moving Backward B
            //5: Moving Right A (also Standing Right)
            //6: Moving Right B
            //7: Moving Left A (also Standing Left)
            //8: Moving Left B
            //9: Attacking Down
            //10: Attacking Up
            //11: Attacking Right
            //12: Attacking Left

            player1Texes[0] = gameMain.Content.Load<Texture2D>(@"Player1");
            player1Texes[1] = gameMain.Content.Load<Texture2D>(@"Player1MoveA");
            player1Texes[2] = gameMain.Content.Load<Texture2D>(@"Player1MoveB");
            player1Texes[3] = gameMain.Content.Load<Texture2D>(@"Player1MoveAwayA");
            player1Texes[4] = gameMain.Content.Load<Texture2D>(@"Player1MoveAwayB");
            player1Texes[5] = gameMain.Content.Load<Texture2D>(@"Player1MoveRightA");
            player1Texes[6] = gameMain.Content.Load<Texture2D>(@"Player1MoveRightB");
            player1Texes[7] = gameMain.Content.Load<Texture2D>(@"Player1MoveLeftA");
            player1Texes[8] = gameMain.Content.Load<Texture2D>(@"Player1MoveLeftB");
            player1Texes[9] = gameMain.Content.Load<Texture2D>(@"Player1Attack");
            player1Texes[10] = gameMain.Content.Load<Texture2D>(@"Player1MoveAwayA");
            player1Texes[11] = gameMain.Content.Load<Texture2D>(@"Player1AttackLeft");
            player1Texes[12] = gameMain.Content.Load<Texture2D>(@"Player1AttackRight");

            player2Texes[0] = gameMain.Content.Load<Texture2D>(@"Player2");
            player2Texes[1] = gameMain.Content.Load<Texture2D>(@"Player2MoveA");
            player2Texes[2] = gameMain.Content.Load<Texture2D>(@"Player2MoveB");
            player2Texes[3] = gameMain.Content.Load<Texture2D>(@"Player2MoveAwayA");
            player2Texes[4] = gameMain.Content.Load<Texture2D>(@"Player2MoveAwayB");
            player2Texes[5] = gameMain.Content.Load<Texture2D>(@"Player2MoveRightA");
            player2Texes[6] = gameMain.Content.Load<Texture2D>(@"Player2MoveRightB");
            player2Texes[7] = gameMain.Content.Load<Texture2D>(@"Player2MoveLeftA");
            player2Texes[8] = gameMain.Content.Load<Texture2D>(@"Player2MoveLeftB");
            player2Texes[9] = gameMain.Content.Load<Texture2D>(@"Player2Attack");
            player2Texes[10] = gameMain.Content.Load<Texture2D>(@"Player2MoveAwayA");
            player2Texes[11] = gameMain.Content.Load<Texture2D>(@"Player2AttackLeft");
            player2Texes[12] = gameMain.Content.Load<Texture2D>(@"Player2AttackRight");

            player3Texes[0] = gameMain.Content.Load<Texture2D>(@"Player3");
            player3Texes[1] = gameMain.Content.Load<Texture2D>(@"Player3MoveA");
            player3Texes[2] = gameMain.Content.Load<Texture2D>(@"Player3MoveB");
            player3Texes[3] = gameMain.Content.Load<Texture2D>(@"Player3MoveAwayA");
            player3Texes[4] = gameMain.Content.Load<Texture2D>(@"Player3MoveAwayB");
            player3Texes[5] = gameMain.Content.Load<Texture2D>(@"Player3MoveRightA");
            player3Texes[6] = gameMain.Content.Load<Texture2D>(@"Player3MoveRightB");
            player3Texes[7] = gameMain.Content.Load<Texture2D>(@"Player3MoveLeftA");
            player3Texes[8] = gameMain.Content.Load<Texture2D>(@"Player3MoveLeftB");
            player3Texes[9] = gameMain.Content.Load<Texture2D>(@"Player3MoveA");
            player3Texes[10] = gameMain.Content.Load<Texture2D>(@"Player3Attack");
            player3Texes[11] = gameMain.Content.Load<Texture2D>(@"Player3AttackLeft");
            player3Texes[12] = gameMain.Content.Load<Texture2D>(@"Player3AttackRight");

            player4Texes[0] = gameMain.Content.Load<Texture2D>(@"Player4");
            player4Texes[1] = gameMain.Content.Load<Texture2D>(@"Player4MoveA");
            player4Texes[2] = gameMain.Content.Load<Texture2D>(@"Player4MoveB");
            player4Texes[3] = gameMain.Content.Load<Texture2D>(@"Player4MoveAwayA");
            player4Texes[4] = gameMain.Content.Load<Texture2D>(@"Player4MoveAwayB");
            player4Texes[5] = gameMain.Content.Load<Texture2D>(@"Player4MoveRightA");
            player4Texes[6] = gameMain.Content.Load<Texture2D>(@"Player4MoveRightB");
            player4Texes[7] = gameMain.Content.Load<Texture2D>(@"Player4MoveLeftA");
            player4Texes[8] = gameMain.Content.Load<Texture2D>(@"Player4MoveLeftB");
            player4Texes[9] = gameMain.Content.Load<Texture2D>(@"Player4MoveA");
            player4Texes[10] = gameMain.Content.Load<Texture2D>(@"Player4Attack");
            player4Texes[11] = gameMain.Content.Load<Texture2D>(@"Player4AttackLeft");
            player4Texes[12] = gameMain.Content.Load<Texture2D>(@"Player4AttackRight");

            sheepTexes[0] = gameMain.Content.Load<Texture2D>(@"SheepFront");
            sheepTexes[1] = gameMain.Content.Load<Texture2D>(@"SheepMoveA");
            sheepTexes[2] = gameMain.Content.Load<Texture2D>(@"SheepMoveB");
            sheepTexes[3] = gameMain.Content.Load<Texture2D>(@"SheepMoveAwayA");
            sheepTexes[4] = gameMain.Content.Load<Texture2D>(@"SheepMoveAwayB");

            barTex = gameMain.Content.Load<Texture2D>(@"BarBackground");
            heartometerTex = gameMain.Content.Load<Texture2D>(@"Heartometer");

            groundTex = gameMain.Content.Load<Texture2D>(@"Ground");
        }

        public void reset(GameMain gameMain)
        {
            sheep.Clear();
            sheepGhosts.Clear();
            initialize(gameMain);
        }

        public override void update(GameMain gameMain)
        {
            time++;
            
            Random r = new Random();

            Vector2 spawnPos;
            switch (r.Next(4))
            {
                case 0:
                    do
                    {
                        spawnPos = new Vector2(-506, r.Next(1008) - 512);
                        Player nearest = Utils.getNearestPlayer(spawnPos);
                        if (nearest == null) break;
                    }
                    while(Utils.getDistance(spawnPos, Utils.getNearestPlayer(spawnPos).position) < 300);
                    break;
                case 1:
                    do
                    {
                        spawnPos = new Vector2(r.Next(1008) - 512, -506);
                        Player nearest = Utils.getNearestPlayer(spawnPos);
                        if (nearest == null) break;
                    }
                    while (Utils.getDistance(spawnPos, Utils.getNearestPlayer(spawnPos).position) < 300);
                    break;
                case 2:
                    do
                    {
                        spawnPos = new Vector2(506, r.Next(1008) - 512);
                        Player nearest = Utils.getNearestPlayer(spawnPos);
                        if (nearest == null) break;
                    }
                    while (Utils.getDistance(spawnPos, Utils.getNearestPlayer(spawnPos).position) < 300);
                    break;
                case 3:
                    do
                    {
                        spawnPos = new Vector2(r.Next(1008) - 512, 506);
                        Player nearest = Utils.getNearestPlayer(spawnPos);
                        if (nearest == null) break;
                    }
                    while (Utils.getDistance(spawnPos, Utils.getNearestPlayer(spawnPos).position) < 300);
                    break;
            }

            double ang = r.NextDouble() * (Math.PI * 2);
            if (sheep.Count < sheepLimit && r.Next(30) == 1) sheep.AddLast(new Sheep(Utils.getAveragePlayerPos() + new Vector2((float)Math.Sin(ang) * 128, (float)Math.Cos(ang) * 128)));

            if (players[0].isActive) players[0].update(GamePad.GetState(PlayerIndex.One), Keyboard.GetState());
            if (players[1].isActive) players[1].update(GamePad.GetState(PlayerIndex.Two), Keyboard.GetState());
            if (players[2].isActive) players[2].update(GamePad.GetState(PlayerIndex.Three), Keyboard.GetState());
            if (players[3].isActive) players[3].update(GamePad.GetState(PlayerIndex.Four), Keyboard.GetState());

            if ((!players[0].isActive || !players[0].isAlive) &&
                (!players[1].isActive || !players[1].isAlive) &&
                (!players[2].isActive || !players[2].isAlive) &&
                (!players[3].isActive || !players[3].isAlive))
                gameMain.currentScreen = GameMain.endGameMenuScreen;

            foreach (Sheep S in sheep.ToList<Sheep>()) S.update();

            camera.update();

            updateGhosts();

            handleInput();

            detectCollisions();
        }

        public void updateGhosts()
        {
            LinkedList<SheepGhost> expired = new LinkedList<SheepGhost>();
            foreach (SheepGhost ghost in sheepGhosts)
            {
                ghost.position.Y -= 2;
                if (camera.worldToCameraRelative(ghost.position).Y < (camera.position.Y - 300))
                    expired.AddLast(ghost);
            }
            foreach (SheepGhost e in expired) { sheepGhosts.Remove(e); }
        }

        public void handleInput()
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Start == ButtonState.Pressed) GameMain.instance.currentScreen = GameMain.pauseMenuScreen;
            
            if (GamePad.GetState(PlayerIndex.One).Buttons.Y == ButtonState.Pressed && !exitButtonPressed[0])
            {
                exitButtonPressed[0] = true;
                if (players[0].isActive) players[0].isActive = false;
                else players[0].isActive = true;
            }
            else if (GamePad.GetState(PlayerIndex.One).Buttons.Y == ButtonState.Released && exitButtonPressed[0]) exitButtonPressed[0] = false;

            if (GamePad.GetState(PlayerIndex.Two).Buttons.Y == ButtonState.Pressed && !exitButtonPressed[1])
            {
                exitButtonPressed[1] = true;
                if (players[1].isActive) players[1].isActive = false;
                else players[1].isActive = true;
            }
            else if (GamePad.GetState(PlayerIndex.Two).Buttons.Y == ButtonState.Released && exitButtonPressed[1]) exitButtonPressed[1] = false;

            if (GamePad.GetState(PlayerIndex.Three).Buttons.Y == ButtonState.Pressed && !exitButtonPressed[2])
            {
                exitButtonPressed[2] = true;
                if (players[2].isActive) players[2].isActive = false;
                else players[2].isActive = true;
            }
            else if (GamePad.GetState(PlayerIndex.Three).Buttons.Y == ButtonState.Released && exitButtonPressed[2]) exitButtonPressed[2] = false;

            if (GamePad.GetState(PlayerIndex.Four).Buttons.Y == ButtonState.Pressed && !exitButtonPressed[3])
            {
                exitButtonPressed[3] = true;
                if (players[3].isActive) players[3].isActive = false;
                else players[3].isActive = true;
            }
            else if (GamePad.GetState(PlayerIndex.Four).Buttons.Y == ButtonState.Released && exitButtonPressed[3]) exitButtonPressed[3] = false;
        }

        public void detectCollisions()
        {
            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    if (i == j) continue;
                    double dist = Utils.getDistance(players[i].position, players[j].position) - ((players[i].getTexture(i).Width / 2) + (players[j].getTexture(j).Width / 2));
                    if (dist < 0)
                    {
                        players[i].move(Vector2.Transform(new Vector2(0, (float)-dist), Matrix.CreateRotationZ((float)players[i].rotation)));
                    }
                }
            }

            foreach (Sheep S in sheep)
            {
                for (int i = 0; i < 4; i++)
                {
                    double dist = Utils.getDistance(S.position, players[i].position) - ((S.getTexture().Width / 2) + (players[i].getTexture(i).Width / 2));
                    if (dist < 0)
                    {
                        S.move(Vector2.Transform(new Vector2(0, (float)-dist / 2), Matrix.CreateRotationZ((float)S.rotation)));
                    }

                    foreach (Sheep Sh in sheep)
                    {
                        if (S == Sh) continue;
                        dist = Utils.getDistance(S.position, Sh.position) - (S.getTexture().Width * 2);
                        if (dist < 0)
                        {
                            S.move(Vector2.Transform(new Vector2(0, (float)-dist), Matrix.CreateRotationZ((float)S.rotation)));
                        }
                    }
                }
            }
        }

        public override void draw(GameMain gameMain)
        {
            SpriteBatch spriteBatch = gameMain.spriteBatch;
            
            Vector2 vect = camera.worldToCameraRelative(new Vector2(-1024, -1024));
            spriteBatch.Draw(groundTex, new Rectangle((int)vect.X, (int)vect.Y, 2048, 2048), Color.ForestGreen);

            if (players[0].isActive && players[0].isAlive)
            {
                spriteBatch.Draw(players[0].getTexture(0), camera.worldToCameraRelative(players[0].position), null, Color.White, 0, new Vector2(15, 16), 1.25f, SpriteEffects.None, 0);
                spriteBatch.DrawString(boldGameFont, "P1", camera.worldToCameraRelative(players[0].position) + new Vector2(-8, -40), Color.Gold);
            }
            if (players[1].isActive && players[1].isAlive)
            {
                spriteBatch.Draw(players[1].getTexture(0), camera.worldToCameraRelative(players[1].position), null, Color.White, 0, new Vector2(15, 16), 1.25f, SpriteEffects.None, 0);
                spriteBatch.DrawString(boldGameFont, "P2", camera.worldToCameraRelative(players[1].position) + new Vector2(-8, -40), Color.Gold);

            }
            if (players[2].isActive && players[2].isAlive)
            {
                spriteBatch.Draw(players[2].getTexture(0), camera.worldToCameraRelative(players[2].position), null, Color.White, 0, new Vector2(15, 16), 1.25f, SpriteEffects.None, 0);
                spriteBatch.DrawString(boldGameFont, "P3", camera.worldToCameraRelative(players[2].position) + new Vector2(-8, -40), Color.Gold);
            }
            if (players[3].isActive && players[3].isAlive)
            {
                spriteBatch.Draw(players[3].getTexture(0), camera.worldToCameraRelative(players[3].position), null, Color.White, 0, new Vector2(15, 16), 1.25f, SpriteEffects.None, 0);
                spriteBatch.DrawString(boldGameFont, "P4", camera.worldToCameraRelative(players[3].position) + new Vector2(-8, -40), Color.Gold);
            }

            foreach (Sheep S in sheep) spriteBatch.Draw(S.getTexture(), camera.worldToCameraRelative(S.position), null, Color.White, 0, new Vector2(13, 23), 1, SpriteEffects.None, 0);

            foreach (SheepGhost G in sheepGhosts) spriteBatch.Draw(sheepTexes[0], camera.worldToCameraRelative(G.position), null, Color.FromNonPremultiplied(255, 255, 255, 128), 0, new Vector2(13, 23), 1, SpriteEffects.None, 0);

            if (players[0].isActive)
            {
                if (players[0].isAlive)
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 8), Color.Red, players[0].health / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 28), Color.Orange, players[0].stamina / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 48), Color.Gray, players[0].armour / 100f);
                }
                else
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 8), Color.DarkGray, 1 - ((float)players[0].respawnTimer / 150f));
                    Heartometer.Draw(spriteBatch, heartometerTex, new Vector2(8, 28), Color.White, (float)players[0].livesRemaining / 5f);
                }
            }
            else if (GamePad.GetState(PlayerIndex.One).IsConnected) spriteBatch.DrawString(boldGameFont, "P1: Press Y to enter the game", new Vector2(8, 8), Color.Gold);

            if (players[1].isActive)
            {
                if (players[1].isAlive)
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 8), Color.Red, players[1].health / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 28), Color.Orange, players[1].stamina / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 48), Color.Gray, players[1].armour / 100f);
                }
                else
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 8), Color.DarkGray, 1 - ((float)players[1].respawnTimer / 150f));
                    Heartometer.Draw(spriteBatch, heartometerTex, new Vector2(800 - 108, 28), Color.White, (float)players[1].livesRemaining / 5f);
                }
            }
            else if (GamePad.GetState(PlayerIndex.Two).IsConnected) spriteBatch.DrawString(boldGameFont, "P2: Press Y to enter the game", new Vector2(800 - (8 + boldGameFont.MeasureString("P2: Press Y to enter the game").X), 8), Color.Black);

            if (players[2].isActive)
            {
                if (players[2].isAlive)
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 600 - 60), Color.Red, players[2].health / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 600 - 40), Color.Orange, players[2].stamina / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 600 - 20), Color.Gray, players[2].armour / 100f);
                }
                else
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(8, 600 - 40), Color.DarkGray, 1 - ((float)players[2].respawnTimer / 150f));
                    Heartometer.Draw(spriteBatch, heartometerTex, new Vector2(8, 600 - 20), Color.White, (float)players[2].livesRemaining / 5f);
                }
            }
            else if (GamePad.GetState(PlayerIndex.Three).IsConnected) spriteBatch.DrawString(boldGameFont, "P3: Press Y to enter the game", new Vector2(8, 600 - 20), Color.Black);

            if (players[3].isActive)
            {
                if (players[3].isAlive)
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 600 - 60), Color.Red, players[3].health / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 600 - 40), Color.Orange, players[3].stamina / 100f);
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 600 - 20), Color.Gray, players[3].armour / 100f);
                }
                else
                {
                    StatusBar.Draw(spriteBatch, barTex, new Vector2(800 - 108, 600 - 40), Color.DarkGray, 1 - ((float)players[3].respawnTimer / 150f));
                    Heartometer.Draw(spriteBatch, heartometerTex, new Vector2(800 - 108, 600 - 20), Color.White, (float)players[3].livesRemaining / 5f);
                }
            }
            else if (GamePad.GetState(PlayerIndex.Four).IsConnected) spriteBatch.DrawString(boldGameFont, "P4: Press Y to enter the game", new Vector2(800 - (8 + boldGameFont.MeasureString("P4: Press Y to enter the game").X), 600 - 20), Color.Black);
        }
    }
}
