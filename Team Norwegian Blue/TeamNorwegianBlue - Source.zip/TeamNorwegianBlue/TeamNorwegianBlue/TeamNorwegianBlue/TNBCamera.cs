﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;

namespace TeamNorwegianBlue
{
    public class TNBCamera
    {
        public Vector2 position;
        Matrix camTransform;
        public TNBCamera(Vector2 pos)
        {
            position = pos;
        }

        public void update()
        {
            position = Utils.getAveragePlayerPos();
            Vector3 pos = new Vector3(-position, 0);
            float scale = 1f;
            //float scale = 1 / (1 + ((float) Utils.getMaxPlayerDistance()) / 400f);
            camTransform = Matrix.CreateTranslation(pos) * Matrix.CreateScale(new Vector3(scale, scale, 1));
        }

        public void move(Vector2 movement)
        {
            position += movement;
        }

        public void setPosition(Vector2 pos)
        {
            position = pos;
        }

        public Vector2 worldToCameraRelative(Vector2 vector)
        {
            return Vector2.Transform(vector + new Vector2(400, 300), camTransform);
        }
    }
}
