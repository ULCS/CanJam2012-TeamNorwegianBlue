﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace TeamNorwegianBlue
{
    public class Player : Mob
    {
        public bool isActive;
        public bool isAlive;
        public byte livesRemaining;
        public int respawnTimer;
        public int stamina;
        int staminaTimer;
        public float armour;

        int attackCooldown;
        bool moving;

        public Player(Vector2 pos)
            : base(100)
        {
            position = pos;
            isActive = false;
            isAlive = true;
            livesRemaining = 1;
            stamina = 100;
            staminaTimer = 0;
            armour = 100;
        }

        public void update(GamePadState GPState, KeyboardState KBState)
        {
            if (!isAlive)
            {
                if (respawnTimer > 0)
                {
                    respawnTimer--;
                    if (respawnTimer == 0 && livesRemaining > 0)
                        respawn();
                }
                return;
            }
            else if (health <= 0)
            {
                die();
                return;
            }

            if (stamina < 100 && staminaTimer <= 0)
            {
                stamina++;
                if (GPState.ThumbSticks.Left.Length() > 0.25f || GPState.ThumbSticks.Left.Length() < -0.25f)
                    staminaTimer = 5;
                else
                    staminaTimer = 2;
            }
            else staminaTimer--;

            if (GPState != null)
            {
                if (stamina > 0 && GPState.Triggers.Left > 0.25f && (GPState.ThumbSticks.Left.Y > 0.25f || GPState.ThumbSticks.Left.Y < -0.25f))
                {

                    //move(Vector2.Transform(new Vector2(0, -GPState.ThumbSticks.Left.Y * 4), Matrix.CreateRotationZ((float)rotation)));
                    move(new Vector2(GPState.ThumbSticks.Left.X * 4, -GPState.ThumbSticks.Left.Y * 4));
                    rotation = Math.Atan2(GPState.ThumbSticks.Left.X, -GPState.ThumbSticks.Left.Y);
                    stamina--;
                }
                else
                {
                    //move(Vector2.Transform(new Vector2(0, -GPState.ThumbSticks.Left.Y * 2), Matrix.CreateRotationZ((float)rotation)));
                    move(new Vector2(GPState.ThumbSticks.Left.X * 2, -GPState.ThumbSticks.Left.Y * 2));
                    rotation = Math.Atan2(GPState.ThumbSticks.Left.X, -GPState.ThumbSticks.Left.Y);
                }

                if (GPState.ThumbSticks.Left.Length() > 0)
                { moving = true; movingCounter++; }
                else moving = false;
                
                if (attackCooldown <= 0 && stamina > 20 && GPState.Triggers.Right > 0.75f)
                {
                    attackCooldown = 15;
                    attack();
                }
                if (attackCooldown > 0) attackCooldown--;
                //rotate(GPState.ThumbSticks.Right.X / 12.5);
            }

            if (GPState.ThumbSticks.Left.Length() > 0)
            {
                Vector2 centrePos = Utils.getAveragePlayerPos();
                if (position.X > centrePos.X + 400) position.X = centrePos.X + 400;
                if (position.X < centrePos.X - 400) position.X = centrePos.X - 400;

                if (position.Y > centrePos.Y + 300) position.Y = centrePos.Y + 300;
                if (position.Y < centrePos.Y - 300) position.Y = centrePos.Y - 300;
            }

            if (position.X > 512) position.X = 512;
            if (position.X < - 512) position.X = -512;

            if (position.Y > 512) position.Y = 512;
            if (position.Y < -512) position.Y = -512;
        }

        public override void attacked(int damage)
        {
            if (armour >= 50)
                armour -= damage;
            else if (armour > 0)
            {
                armour -= (damage * (armour / 50));
                health -= (damage * (1 -(armour / 50)));
            }
            else health -= damage;
        }

        protected override void die()
        {
            isAlive = false;
            respawnTimer = 150;
            livesRemaining--;
        }

        protected void respawn()
        {
            Random r = new Random();
            position = Utils.getStrongestPlayer().position + new Vector2(r.Next(32) - 16, r.Next(32) - 16);
            health = 100;
            armour = 100;
            stamina = 100;
            isAlive = true;
        }

        int movingCounter;
        public Texture2D getTexture(int playerNumber)
        {
            double xMove = Math.Sin(rotation);
            double yMove = Math.Cos(rotation);
            if (attackCooldown > 0)
            {
                if (Math.Abs(xMove) > Math.Abs(yMove))
                {
                    if (xMove > 0) //Attack right
                        return GameMain.gameScreen.allPlayerTexes[playerNumber][11];
                    else //Attack left
                        return GameMain.gameScreen.allPlayerTexes[playerNumber][12];
                }
                else
                {
                    if (yMove > 0) //Attack down
                        return GameMain.gameScreen.allPlayerTexes[playerNumber][9];
                    else //Attack up
                        return GameMain.gameScreen.allPlayerTexes[playerNumber][10];
                }
            }

            if(moving)
            {
                if (movingCounter % 12 < 6)
                {
                    if (Math.Abs(xMove) > Math.Abs(yMove))
                    {
                        if (xMove > 0) //Move right A
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][5];
                        else //Move left A
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][7];
                    }
                    else
                    {
                        if (yMove > 0) //Move down A
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][1];
                        else //Move up A
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][3];
                    }
                }
                else
                {
                    if (Math.Abs(xMove) > Math.Abs(yMove))
                    {
                        if (xMove > 0) //Move right B
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][6];
                        else //Move left B
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][8];
                    }
                    else
                    {
                        if (yMove > 0) //Move down B
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][2];
                        else //Move up B
                            return GameMain.gameScreen.allPlayerTexes[playerNumber][4];
                    }
                }
            }

            if (Math.Abs(xMove) > Math.Abs(yMove))
            {
                if (xMove > 0) //Stand Right
                    return GameMain.gameScreen.allPlayerTexes[playerNumber][5];
                else //Stand Left
                    return GameMain.gameScreen.allPlayerTexes[playerNumber][7];
            }
            else
            {
                if (yMove > 0) //Stand Forward
                    return GameMain.gameScreen.allPlayerTexes[playerNumber][0];
                else //Stand Backward
                    return GameMain.gameScreen.allPlayerTexes[playerNumber][3];
            }
        }
    }
}
