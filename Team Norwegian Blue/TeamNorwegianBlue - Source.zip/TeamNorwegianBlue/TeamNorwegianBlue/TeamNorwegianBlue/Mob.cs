﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace TeamNorwegianBlue
{
    public class Mob
    {
        public Vector2 position;
        public double rotation;
        public float health;
        
        public Mob(int startingHealth)
        {
            position = Vector2.Zero;
            rotation = 0;
            health = startingHealth;
        }

        public virtual void update()
        {
            if (health == 0)
                die();
        }

        public void move(Vector2 movement)
        {
            position += movement;
        }

        public void rotate(double rotate)
        {
            rotation += rotate;
        }

        protected virtual void attack()
        {

        }

        public virtual void attacked(int damage)
        {
            health -= damage;
        }

        protected virtual void die()
        {

        }

        public virtual Texture2D getTexture()
        {
            return null;
        }
    }
}
