﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace TeamNorwegianBlue
{
    public class Sheep : Mob
    {
        Player target;
        private int _strength;
        private int range;
        private int attackCooldown;
        bool moving;
        int movingCounter = 0;

        public Sheep(Vector2 pos)
            : base(10)
        {
            _strength = 10;
            range = 48;
            position = pos;
            target = Utils.getNearestPlayer(position);
        }

        public override void update()
        {
            if (attackCooldown > 0)
                attackCooldown--;
            
            target = Utils.getNearestPlayer(position);
            if (target == null)
            {
                if (health <= 0)
                {
                    die();
                }
                return;
            }

            double tempRot = Utils.getAngle(position, target.position);

            if (Utils.getDistance(target.position, position) > range)
            {
                if (rotation < tempRot)
                {
                    rotate(0.25);
                }
                else
                {
                    rotate(-0.25);
                }

                move(Vector2.Transform(new Vector2(0, -0.5f), Matrix.CreateRotationZ((float)tempRot)));
                moving = true; movingCounter++;
            }
            else if (attackCooldown <= 0)
            {
                attack();
                moving = false;
            }
            else moving = false;

            if (health <= 0)
            {
                die();
            }
        }
        
        protected override void attack()
        {
            Mob[] hit = Utils.rayTrace(this, range);
            if(hit != null && hit.Length > 0 && !(hit[0] is Sheep)) hit[0].attacked(_strength);
            attackCooldown = 30;
        }

        public override void attacked(int damage)
        {
            die();
        }

        protected override void die()
        {
            GameMain.gameScreen.sheep.Remove(this);
            GameMain.gameScreen.sheepGhosts.AddLast(new SheepGhost(position));
            GameMain.gameScreen.score += 100;
            if ((GameMain.gameScreen.score % 500) == 0)
            {
                GameMain.gameScreen.sheepLimit++;
            }
        }

        public override Texture2D getTexture()
        {
            double xMove = Math.Sin(rotation);
            double yMove = Math.Cos(rotation);
            if (moving)
            {
                if (movingCounter % 12 < 6)
                {
                    if(yMove > 0)
                        return GameMain.gameScreen.sheepTexes[3];
                    else
                        return GameMain.gameScreen.sheepTexes[1];
                }
                else
                {
                    if (yMove > 0)
                        return GameMain.gameScreen.sheepTexes[4];
                    else
                        return GameMain.gameScreen.sheepTexes[2];
                }
            }
            return GameMain.gameScreen.sheepTexes[0];
        }
    }
}
