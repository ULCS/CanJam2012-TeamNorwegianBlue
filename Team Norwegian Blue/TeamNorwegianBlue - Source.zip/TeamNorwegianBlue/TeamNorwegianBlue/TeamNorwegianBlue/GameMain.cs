using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

namespace TeamNorwegianBlue
{
    /// <summary>
    /// This is the main type for your game
    /// </summary>
    public class GameMain : Microsoft.Xna.Framework.Game
    {
        public static GameMain instance;
        public static GameScreen gameScreen;
        public static MainMenuScreen mainMenuScreen;
        public static PauseMenuScreen pauseMenuScreen;
        public static EndGameMenuScreen endGameMenuScreen;

        GraphicsDeviceManager graphics;
        public SpriteBatch spriteBatch;
        GraphicsDevice device;
        public Screen currentScreen;

        public GameMain()
        {
            instance = this;
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";

            gameScreen = new GameScreen();
            mainMenuScreen = new MainMenuScreen();
            pauseMenuScreen = new PauseMenuScreen();
            endGameMenuScreen = new EndGameMenuScreen();

            currentScreen = mainMenuScreen;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = 800;
            graphics.PreferredBackBufferHeight = 600;
            graphics.IsFullScreen = false;
            graphics.ApplyChanges();
            IsMouseVisible = true;
            Window.Title = "Shepherds of Doom";

            mainMenuScreen.initialize(instance);
            gameScreen.initialize(instance);
            pauseMenuScreen.initialize(instance);
            endGameMenuScreen.initialize(instance);

            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            // Create a new SpriteBatch, which can be used to draw textures.
            device = graphics.GraphicsDevice;
            spriteBatch = new SpriteBatch(GraphicsDevice);

            mainMenuScreen.loadContent(instance);
            gameScreen.loadContent(instance);
            pauseMenuScreen.loadContent(instance);
            endGameMenuScreen.loadContent(instance);
        }

        /// <summary>
        /// UnloadContent will be called once per game and is the place to unload
        /// all content.
        /// </summary>
        protected override void UnloadContent()
        {
            // TODO: Unload any non ContentManager content here
        }

        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)  this.Exit();
            if (GamePad.GetState(PlayerIndex.Two).Buttons.Back == ButtonState.Pressed) this.Exit();
            if (GamePad.GetState(PlayerIndex.Three).Buttons.Back == ButtonState.Pressed) this.Exit();
            if (GamePad.GetState(PlayerIndex.Four).Buttons.Back == ButtonState.Pressed) this.Exit();

            currentScreen.update(instance);

            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.CornflowerBlue);

            spriteBatch.Begin();

            currentScreen.draw(instance);

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}
