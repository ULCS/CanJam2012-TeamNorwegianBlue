﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TeamNorwegianBlue
{
    public class Button
    {
        public virtual void onClick(GameMain gameMain)
        {

        }

        //public virtual void 
    }
}
