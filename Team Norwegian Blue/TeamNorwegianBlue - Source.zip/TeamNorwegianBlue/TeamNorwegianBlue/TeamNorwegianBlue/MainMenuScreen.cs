﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

namespace TeamNorwegianBlue
{
    public class MainMenuScreen : Screen
    {
        public SpriteFont titleMainMenuFont;
        public SpriteFont boldMainMenuFont;
        public Texture2D mainMenuBackground;
        public Texture2D mainMenuBackgroundCracks;
        public Texture2D buttonBackground;
        public Texture2D gameLogo;

        int currentSelection;
        int selectionChangeCooldown;
        int selectionCooldown;
        
        public override void initialize(GameMain gameMain)
        {
            currentSelection = 0;
        }

        public override void loadContent(GameMain gameMain)
        {
            titleMainMenuFont = gameMain.Content.Load<SpriteFont>(@"TitleMainMenuFont");
            boldMainMenuFont = gameMain.Content.Load<SpriteFont>(@"BoldMainMenuFont");
            mainMenuBackground = gameMain.Content.Load<Texture2D>(@"PauseBackgroundShade");
            mainMenuBackgroundCracks = gameMain.Content.Load<Texture2D>(@"cracks");
            buttonBackground = gameMain.Content.Load<Texture2D>(@"MenuButton");
            gameLogo = gameMain.Content.Load<Texture2D>(@"logo");
        }

        public override void update(GameMain gameMain)
        {
            if (selectionChangeCooldown == 0 && GamePad.GetState(PlayerIndex.One).ThumbSticks.Left.Y < -0.1f && currentSelection < 2) { currentSelection++; selectionChangeCooldown = 15;}
            if (selectionChangeCooldown == 0 && GamePad.GetState(PlayerIndex.One).ThumbSticks.Left.Y > 0.1f && currentSelection > 0) { currentSelection--; selectionChangeCooldown = 15; }
            if (selectionChangeCooldown > 0) selectionChangeCooldown--;

            if (selectionCooldown == 0 && GamePad.GetState(PlayerIndex.One).Buttons.A == ButtonState.Pressed)
            {
                switch (currentSelection)
                {
                    case 0:
                        gameMain.currentScreen = GameMain.gameScreen;
                        break;
                    case 1:
                        currentSelection = 3;
                        break;
                    case 2:
                        gameMain.Exit();
                        break;
                    case 3:
                        currentSelection = 1;
                        break;
                }
                selectionCooldown = 15;
            }
            if (selectionCooldown > 0) selectionCooldown--;
        }

        public override void draw(GameMain gameMain)
        {
            SpriteBatch spriteBatch = gameMain.spriteBatch;

            spriteBatch.Draw(mainMenuBackground, new Rectangle(0, 0, 800, 600), Color.DarkGray);

            spriteBatch.Draw(mainMenuBackgroundCracks, new Rectangle(0, 0, 800, 600), Color.FromNonPremultiplied(255,255,255,128));

            spriteBatch.DrawString(boldMainMenuFont, "TEAM NORWEGIAN BLUE PRESENTS", new Vector2(400 - boldMainMenuFont.MeasureString("TEAM NORWEGIAN BLUE PRESENTS").X / 2, 8), Color.Navy);

            spriteBatch.Draw(gameLogo, new Rectangle((int)(400 - gameLogo.Width * (1.5 / 2)), (int)(150 - gameLogo.Height * (1.5 / 2)), (int)(gameLogo.Width * 1.5), (int)(gameLogo.Height * 1.5)), Color.White);

            switch(currentSelection)
            {
                case 0:
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("PLAY").X * 2), (int) (300 - boldMainMenuFont.MeasureString("PLAY").Y / 2), (int)boldMainMenuFont.MeasureString("PLAY").X * 4, (int)boldMainMenuFont.MeasureString("PLAY").Y * 2), Color.White);
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("INFO").X * 2), (int)(400 - boldMainMenuFont.MeasureString("INFO").Y / 2), (int)boldMainMenuFont.MeasureString("INFO").X * 4, (int)boldMainMenuFont.MeasureString("INFO").Y * 2), Color.White);
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("QUIT").X * 2), (int)(500 - boldMainMenuFont.MeasureString("QUIT").Y / 2), (int)boldMainMenuFont.MeasureString("QUIT").X * 4, (int)boldMainMenuFont.MeasureString("QUIT").Y * 2), Color.White);
                    spriteBatch.DrawString(boldMainMenuFont, "PLAY", new Vector2(400 - boldMainMenuFont.MeasureString("PLAY").X / 2, 300), Color.Yellow);
                    spriteBatch.DrawString(boldMainMenuFont, "INFO", new Vector2(400 - boldMainMenuFont.MeasureString("INFO").X / 2, 400), Color.Black);
                    spriteBatch.DrawString(boldMainMenuFont, "QUIT", new Vector2(400 - boldMainMenuFont.MeasureString("QUIT").X / 2, 500), Color.Black);
                    break;
                case 1:
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("PLAY").X * 2), (int) (300 - boldMainMenuFont.MeasureString("PLAY").Y / 2), (int)boldMainMenuFont.MeasureString("PLAY").X * 4, (int)boldMainMenuFont.MeasureString("PLAY").Y * 2), Color.White);
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("INFO").X * 2), (int)(400 - boldMainMenuFont.MeasureString("INFO").Y / 2), (int)boldMainMenuFont.MeasureString("INFO").X * 4, (int)boldMainMenuFont.MeasureString("INFO").Y * 2), Color.White);
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("QUIT").X * 2), (int)(500 - boldMainMenuFont.MeasureString("QUIT").Y / 2), (int)boldMainMenuFont.MeasureString("QUIT").X * 4, (int)boldMainMenuFont.MeasureString("QUIT").Y * 2), Color.White);
                    spriteBatch.DrawString(boldMainMenuFont, "PLAY", new Vector2(400 - boldMainMenuFont.MeasureString("PLAY").X / 2, 300), Color.Black);
                    spriteBatch.DrawString(boldMainMenuFont, "INFO", new Vector2(400 - boldMainMenuFont.MeasureString("INFO").X / 2, 400), Color.Yellow);
                    spriteBatch.DrawString(boldMainMenuFont, "QUIT", new Vector2(400 - boldMainMenuFont.MeasureString("QUIT").X / 2, 500), Color.Black);
                    break;
                case 2:
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("PLAY").X * 2), (int) (300 - boldMainMenuFont.MeasureString("PLAY").Y / 2), (int)boldMainMenuFont.MeasureString("PLAY").X * 4, (int)boldMainMenuFont.MeasureString("PLAY").Y * 2), Color.White);
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("INFO").X * 2), (int)(400 - boldMainMenuFont.MeasureString("INFO").Y / 2), (int)boldMainMenuFont.MeasureString("INFO").X * 4, (int)boldMainMenuFont.MeasureString("INFO").Y * 2), Color.White);
                    spriteBatch.Draw(buttonBackground, new Rectangle((int)(400 - boldMainMenuFont.MeasureString("QUIT").X * 2), (int)(500 - boldMainMenuFont.MeasureString("QUIT").Y / 2), (int)boldMainMenuFont.MeasureString("QUIT").X * 4, (int)boldMainMenuFont.MeasureString("QUIT").Y * 2), Color.White);
                    spriteBatch.DrawString(boldMainMenuFont, "PLAY", new Vector2(400 - boldMainMenuFont.MeasureString("PLAY").X / 2, 300), Color.Black);
                    spriteBatch.DrawString(boldMainMenuFont, "INFO", new Vector2(400 - boldMainMenuFont.MeasureString("INFO").X / 2, 400), Color.Black);
                    spriteBatch.DrawString(boldMainMenuFont, "QUIT", new Vector2(400 - boldMainMenuFont.MeasureString("QUIT").X / 2, 500), Color.Yellow);
                    break;
                case 3:
                    spriteBatch.DrawString(boldMainMenuFont, "An evil scientist has mutated the worlds", new Vector2(400 - boldMainMenuFont.MeasureString("An evil scientist has mutated the worlds").X / 2, 250), Color.Yellow);
                    spriteBatch.DrawString(boldMainMenuFont, "sheep and is using them to cause the apocalypse.", new Vector2(400 - boldMainMenuFont.MeasureString(" sheep and is using them to cause the apocalypse.").X / 2, 275), Color.Yellow);
                    spriteBatch.DrawString(boldMainMenuFont, "Fortunately, you and your fellow Viking warriors", new Vector2(400 - boldMainMenuFont.MeasureString("Fortunately, you and your fellow Viking warriors").X / 2, 300), Color.Yellow);
                    spriteBatch.DrawString(boldMainMenuFont, "have been brought through time to 2012 to", new Vector2(400 - boldMainMenuFont.MeasureString("have been brought through time to 2012 to").X / 2, 325), Color.Yellow);
                    spriteBatch.DrawString(boldMainMenuFont, "slay the evil mutant sheep and save the world!", new Vector2(400 - boldMainMenuFont.MeasureString("slay the evil mutant sheep and save the world!").X / 2, 350), Color.Yellow);
                    spriteBatch.DrawString(boldMainMenuFont, "Press A to return to the menu", new Vector2(400 - boldMainMenuFont.MeasureString("Press A to return to the menu").X / 2, 500), Color.Yellow);
                    break;
            }
        }
    }
}
